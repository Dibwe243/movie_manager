var http = require("http");
var server = http.createServer();
var url = require("url");
var my_sql = require("mysql");
/* remote
var my_sql_conn = my_sql.createConnection({
                    host : "www.db4free.net",
                    port : 3306,
                    user : "movie_shop",
                    password : '12345678'
});
*/
//local
//establish connection to db server
var my_sql_conn = my_sql.createConnection({
                    host : "localhost",
                    port : 3306,
                    user : "root",
                    password : ''
});

//connect to existing db
var my_sql_conn_db = my_sql.createConnection({
                    host : "localhost",
                    port : 3306,
                    user : "root",
                    password : '',
                    database : "movie_shop"
});


var body = '<html><head><title>MovieShop</title>'+
           '<script  src="https://code.jquery.com/jquery-3.3.1.min.js"  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="  crossorigin="anonymous"></script>'+
            '</head>'+
            '<body>'+
            '<h1>Hello there</h1><hr>'+
            '<p id ="1">paragraph1</p>'+
            '<p id ="2">paragraph1</p>'+
            '</body></html>';
            

//server
server.on("request",function(request, respond){
   var path = url.parse(request.url).pathname; 
 respond.writeHead(200);
    respond.write(body);
    //respond.write("<script>alert('"+path+"')</script>");
    if(path == '/mysql'){
        routing(respond);
    }
    else{respond.write("<script>document.getElementById('1').innerHTML ='Incorrect url';</script>")};
   
    //respond.end();
    
    
});

//routed to mysql table create
function routing(respond){
    my_sql_conn.connect(function(err){//doing mysql connection handshake aka test connectability
        if(err){
            respond.write("<p>connection error: "+err+"</p>");
            //return respond.end();//ending here
        }
        else{
            respond.write("<p>connected to db</p>");
             //respond.end();//ending here
        }
    //create database give a name;
       my_sql_conn.query("CREATE DATABASE movie_shop",function(err, results){
           
        if(err){
            respond.write("<p>DB creation err "+err+"</p>");
            //return respond.end();//ending here
        }
        else{
            respond.write("<p>DB created "+results+"</p>");
             //respond.end();//ending here
        }
           
       }); 
        
        //create db table
        var mysql_db_table ="CREATE TABLE movie_table(movie_id int NOT NULL AUTO_INCREMENT PRIMARY KEY, m_title varchar(255), m_director varchar(255), m_producer varchar(255), m_production_company varchar(255), m_country varchar(255), m_actor varchar(255), m_genre varchar(255), m_description varchar(255), m_disclaimer varchar(255))";
        
        //connect to existing db
        my_sql_conn_db.query(mysql_db_table, function(err, results){
           
        if(err){
            respond.write("<p>table creation err "+err+"</p>");
           return respond.end();//ending here
        }
        else{
            respond.write("<p>table created "+results+"</p>");
            respond.end();//ending here
        }
           
       }
           
        );
    });
}


server.on("close", function(){console.log("connection closed")});

server.listen(3000);